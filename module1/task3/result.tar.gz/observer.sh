#!/bin/bash

LOG_FILE="observer.log"
CONF_FILE="observer.conf"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

is_running() {
    local name="$1"
    for pid in /proc/[0-9]*; do
        if [[ -r "$pid/comm" ]]; then
            proc_name=$(cat "$pid/comm")
            if [[ "$proc_name" == "$name" ]]; then
                return 0
            fi
        fi
    done
    return 1
}

cd "$SCRIPT_DIR"

while IFS= read -r script_name || [[ -n "$script_name" ]]; do
    NAME="$(basename "$script_name")"
    
    if is_running "$NAME"; then
        echo "$(date "+%d/%m/%Y %H:%M:%S") Script ${NAME} is already running" >> "$LOG_FILE"
    else
        echo "$(date "+%d/%m/%Y %H:%M:%S") Script $NAME isn't running, starting" >> "$LOG_FILE"
        nohup "./$NAME" > /dev/null 2>&1 &
        sleep 0.2
    fi
done < "$CONF_FILE"
